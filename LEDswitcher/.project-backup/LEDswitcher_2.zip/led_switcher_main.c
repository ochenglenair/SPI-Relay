/**
 * \file
 *
 * \brief Application to control an Infineon ISO1H816G evaluation board via SPI.
 *
 * Copyright (c) 2015-2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */

#include "atmel_start.h"
#include "atmel_start_pins.h" // <-- Added this include for pin definitions
#include <hal_gpio.h>
#include <hal_delay.h>
#include <hal_spi_m_sync.h>

// --- Pin Definitions for Infineon Board Control ---
// Note: These pins correspond to a SERCOM peripheral configured for SPI in atmel_start.
// Make sure your project's pin configuration matches these definitions.
// Default for SAM D21 Xplained Pro: SERCOM0
// MOSI: PA05 (Maps to K3 Pin 6 - SI)
// MISO: PA06 (Maps to K3 Pin 13 - SO)
// SCK:  PA07 (Maps to K3 Pin 4 - SCLK)
#define CS_PIN   PA04 // Chip Select (Maps to K3 Pin 3 - /CS)
#define DIS_PIN  PA02 // Disable Pin (Maps to K3 Pin 2 - /DIS)

// SPI peripheral instance from atmel_start
extern struct spi_m_sync_descriptor SPI_0;

/**
 * @brief Sends an 8-bit command to the ISO1H816G chip via SPI.
 * @param command The 8-bit value to send. Each bit corresponds to an output channel.
 */
void send_iso_command(uint8_t command)
{
    struct spi_xfer xfer;
    xfer.txbuf = &command;
    xfer.rxbuf = NULL; // We are not expecting to receive data in this simple case
    xfer.size  = 1;     // Transfer one byte

    // 1. Assert Chip Select (pull it LOW to select the chip)
    gpio_set_pin_level(CS_PIN, false);
    delay_us(1); // Small delay after CS goes low

    // 2. Perform the SPI transfer
    spi_m_sync_transfer(&SPI_0, &xfer);

    // 3. De-assert Chip Select (pull it HIGH to de-select the chip)
    // This latches the data into the ISO1H816G's output registers.
    delay_us(1); // Small delay before CS goes high
    gpio_set_pin_level(CS_PIN, true);
}


int main(void)
{
	uint8_t output_state = 0x00; // Variable to hold the current state of the 8 channels (0x00 = all off)
	bool toggle = false;

	atmel_start_init();

	// --- Initialize Control Pins for Infineon Board ---
	gpio_set_pin_direction(CS_PIN, GPIO_DIRECTION_OUT);
	gpio_set_pin_level(CS_PIN, true); // Chip select is active low, so initialize it to HIGH (inactive)

	gpio_set_pin_direction(DIS_PIN, GPIO_DIRECTION_OUT);
	gpio_set_pin_level(DIS_PIN, true); // Disable pin is active low, initialize to HIGH (outputs enabled)

	// --- Initialize SPI peripheral ---
	spi_m_sync_enable(&SPI_0);

	// Configure the switch pin with an internal pull-up resistor.
	gpio_set_pin_pull_mode(SW0, GPIO_PULL_UP);

	// Initial state: Turn all channels off
	send_iso_command(0x00);

	while (true) {
		// Wait for the button to be pressed (pin goes LOW)
		while (gpio_get_pin_level(SW0)) {
			// Do nothing, just wait for the press.
		}

		// Toggle the state for the output channels
		toggle = !toggle;
		output_state = toggle ? 0xFF : 0x00; // 0xFF = all channels ON, 0x00 = all channels OFF

		// Send the new command to the Infineon board
		send_iso_command(output_state);

		// Debounce delay for press
		delay_ms(50);

		// Wait for the button to be released (pin goes back to HIGH)
		while (!gpio_get_pin_level(SW0)) {
			// Do nothing, just wait for the release.
		}

		// Debounce delay for release
		delay_ms(50);
	}
}
