/**
 * \file
 *
 * \brief Application to control an Infineon ISO1H816G evaluation board via SPI.
 *
 * Copyright (c) 2015-2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */

#include "atmel_start.h"
#include "atmel_start_pins.h" 
#include <hal_gpio.h>
#include <hal_delay.h>
#include <hal_spi_m_sync.h>

// --- Pin Definitions for Infineon Board Control ---
// **IMPORTANT**: These pin assignments must match your MCC configuration.
//
// SPI Peripheral Pins (handled by MCC SERCOM configuration):
// MOSI: PB04 (Maps to K3 Pin 6 - SI)
// MISO: PA06 (Maps to K3 Pin 13 - SO)
// SCK:  PA07 (Maps to K3 Pin 4 - SCLK)
//
// GPIO Control Pins (handled by this code):
#define CS_PIN   PA04 // Chip Select (Maps to K3 Pin 3 - /CS)
#define DIS_PIN  PA02 // Disable Pin (Maps to K3 Pin 2 - /DIS)

// SPI peripheral instance from atmel_start
extern struct spi_m_sync_descriptor SPI_0;

/**
 * @brief Sends commands to both daisy-chained ISO1H816G chips.
 * @param command_k2 The 8-bit command for the chip controlling the K2 connector.
 * @param command_k1 The 8-bit command for the chip controlling the K1 connector.
 */
void send_iso_command(uint8_t command_k2, uint8_t command_k1)
{
    // Create a 2-byte buffer for the SPI transfer.
    // Due to the daisy-chain, the command for the last chip (K2) must be sent first.
    uint8_t commands[2] = {command_k2, command_k1};

    struct spi_xfer xfer;
    xfer.txbuf = commands;
    xfer.rxbuf = NULL;
    xfer.size  = 2; // Transfer two bytes

    // 1. Assert Chip Select (pull it LOW to select the chips)
    gpio_set_pin_level(CS_PIN, false);
    delay_us(1); // Small delay after CS goes low

    // 2. Perform the 16-bit (2-byte) SPI transfer
    spi_m_sync_transfer(&SPI_0, &xfer);

    // 3. De-assert Chip Select (pull it HIGH to de-select the chips)
    // This latches the data into both chips' output registers simultaneously.
    delay_us(1); // Small delay before CS goes high
    gpio_set_pin_level(CS_PIN, true);
}


int main(void)
{
	/* --- SPI LOOPBACK TEST --- */
	uint8_t byte_to_send = 0xAA; // A pattern of alternating 1s and 0s (10101010)
	uint8_t received_byte = 0x00;

	atmel_start_init();

	// Initialize the SPI peripheral
	spi_m_sync_enable(&SPI_0);
	
	// We don't need the CS or DIS pins for this test, but we'll set them to a safe state.
	gpio_set_pin_direction(CS_PIN, GPIO_DIRECTION_OUT);
	gpio_set_pin_level(CS_PIN, true); 
	gpio_set_pin_direction(DIS_PIN, GPIO_DIRECTION_OUT);
	gpio_set_pin_level(DIS_PIN, true);

	// Set LED0 to off initially (active-low)
	gpio_set_pin_level(LED0, true);

	while (true) {
		// Prepare the SPI transfer structure
		struct spi_xfer xfer;
		xfer.txbuf = &byte_to_send;
		xfer.rxbuf = &received_byte; // We want to read what comes back
		xfer.size  = 1;

		// Perform the transfer
		spi_m_sync_transfer(&SPI_0, &xfer);

		// Check if we received what we sent
		if (received_byte == byte_to_send) {
			// Success! Toggle the LED to show it's working.
			gpio_toggle_pin_level(LED0);
		}
		
		// Wait before the next test
		delay_ms(500);
	}
}
